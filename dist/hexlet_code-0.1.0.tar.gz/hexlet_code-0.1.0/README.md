### Hexlet tests and linter status:
[![Actions Status](https://github.com/Roodmann/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Roodmann/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/08a3050c6398933601a6/maintainability)](https://codeclimate.com/github/Roodmann/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/08a3050c6398933601a6/test_coverage)](https://codeclimate.com/github/Roodmann/python-project-50/test_coverage)
[![Python CI](https://github.com/Roodmann/python-project-50/actions/workflows/pyci.yml/badge.svg)](https://github.com/Roodmann/python-project-50/actions/workflows/pyci.yml)