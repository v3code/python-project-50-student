### Hexlet tests and linter status:
[![Actions Status](https://github.com/Roodmann/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Roodmann/python-project-50/actions)