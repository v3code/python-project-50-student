print(1)

